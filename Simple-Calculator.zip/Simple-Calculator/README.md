# Simple-Calculator
A simple calculator written in python. This is for Assignment 9 in DevTools &amp; Practices Course: Collaborative Models with GitHub, Agile Software Development. 
